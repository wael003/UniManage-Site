﻿# UniManage-Site
 
 #folder back 
npm install
node server.js

#folder front
npm install
npm run dev

#.env
you need to identify this:
PORT , //Server port
DBURL , //MONGO_DB URL
JWT_SECRET ,
NODE_ENV =  'production',
NODEMILER_PORT, //like 587 
NODEMILER_USER, // this is the email you use to send messages
NODEMILER_PASSKEY, // this is the passkey you get for the email
